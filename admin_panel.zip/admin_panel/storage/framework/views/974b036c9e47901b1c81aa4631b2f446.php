
<?php
$user_role = Auth::user()->user_role;
?><ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

            <!-- Sidebar - Brand -->
            <a class="sidebar-brand d-flex align-items-center justify-content-center" href="<?php echo e(route('dashboard')); ?>">
                <div class="sidebar-brand-icon rotate-n-15">
                    <!-- <i class="fas fa-laugh-wink"></i> -->
                </div>
                <?php if($user_role === 'admin'): ?>
                <div class="sidebar-brand-text mx-3">Admin</div>
                <?php elseif($user_role === 'vendor'): ?>
                <div class="sidebar-brand-text mx-3">Vendor</div>
                <?php elseif($user_role === 'user'): ?>
                <div class="sidebar-brand-text mx-3">Hi,<?php echo e(Auth::user()->name); ?></div>
                <?php endif; ?>
            </a>

            <!-- Divider -->
            <hr class="sidebar-divider my-0">

            <!-- Nav Item - Dashboard -->
            <li class="nav-item active">
                <a class="nav-link" href="<?php echo e(route('dashboard')); ?>">
                    <i class="fas fa-fw fa-tachometer-alt"></i>
                    <span>Dashboard</span></a>
            </li>

            <!-- Divider -->
            <hr class="sidebar-divider">

            <!-- Heading -->
            <!-- <div class="sidebar-heading">
                Interface
            </div> -->

            <!-- Nav Item - Pages Collapse Menu -->
             <?php if($user_role === 'admin'): ?>
            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseTwo"
                    aria-expanded="true" aria-controls="collapseTwo">
                    <i class="fas fa-fw fa-user"></i>
                    <span>Users</span>
                </a>
                <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <h6 class="collapse-header">User:</h6>
                        <a class="collapse-item" href="<?php echo e(URL::to('add-user')); ?>">Add user</a>
                        <a class="collapse-item" href="<?php echo e(URL::to('view-user')); ?>">User list</a>
                    </div>
                </div>
            </li>
            <?php endif; ?>
             <?php if($user_role === 'admin' || $user_role === 'vendor'): ?>
            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseThree"
                    aria-expanded="true" aria-controls="collapseThree">
                    <i class="fas fa-fw fa-user"></i>
                    <span>Customers</span>
                </a>
                <div id="collapseThree" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <h6 class="collapse-header">Customer:</h6>
                        <a class="collapse-item" href="<?php echo e(URL::to('add-customer')); ?>">Add customer</a>
                        <a class="collapse-item" href="<?php echo e(URL::to('view-customer')); ?>">Customer list</a>
                    </div>
                </div>
            </li>
            <?php endif; ?>
            <?php if($user_role === 'admin' || $user_role === 'vendor' || $user_role === 'user'): ?>
            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseFour"
                    aria-expanded="true" aria-controls="collapseFour">
                    <i class="fas fa-fw fa-tasks"></i>
                    <span>Tasks</span>
                </a>
                <div id="collapseFour" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <h6 class="collapse-header">Tasks:</h6>
                        <?php if($user_role === 'admin' || $user_role === 'vendor'): ?>
                        <a class="collapse-item" href="<?php echo e(URL::to('add-task')); ?>">Add Task</a>
                        <?php endif; ?>
                        <a class="collapse-item" href="<?php echo e(URL::to('view-task')); ?>">Task list</a>
                    </div>
                </div>
            </li>
            <?php endif; ?>
            <?php if($user_role === 'admin' || $user_role === 'vendor'): ?>
            <li class="nav-item">
                <a class="nav-link"  href="<?php echo e(URL::to('view-lead')); ?>">
                    <i class="fas fa-fw fa-address-book"></i>
                    <span>Leads</span>
                </a>
                <!-- <div id="collapseFive" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <h6 class="collapse-header">Leads:</h6>
                        <a class="collapse-item" href="<?php echo e(URL::to('add-lead')); ?>">Add Lead</a>
                        <a class="collapse-item" href="<?php echo e(URL::to('view-leads')); ?>">Leads list</a>
                    </div>
                </div> -->
            </li>
            <?php endif; ?>
             <?php if($user_role === 'admin' ): ?>
            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(URL::to('roles-permission')); ?>">
                    <i class="fas fa-fw fa-wrench"></i>
                    <span>Roles & Pesrmission</span>
                </a>
            </li>
            <?php endif; ?>
            <!-- <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseTwo"
                    aria-expanded="true" aria-controls="collapseTwo">
                    <i class="fas fa-fw fa-cog"></i>
                    <span>Components</span>
                </a>
                <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <h6 class="collapse-header">Custom Components:</h6>
                        <a class="collapse-item" href="buttons.html">Buttons</a>
                        <a class="collapse-item" href="cards.html">Cards</a>
                    </div>
                </div>
            </li> -->

            <!-- Nav Item - Utilities Collapse Menu -->
            <!-- <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseUtilities"
                    aria-expanded="true" aria-controls="collapseUtilities">
                    <i class="fas fa-fw fa-wrench"></i>
                    <span>Utilities</span>
                </a>
                <div id="collapseUtilities" class="collapse" aria-labelledby="headingUtilities"
                    data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <h6 class="collapse-header">Custom Utilities:</h6>
                        <a class="collapse-item" href="utilities-color.html">Colors</a>
                        <a class="collapse-item" href="utilities-border.html">Borders</a>
                        <a class="collapse-item" href="utilities-animation.html">Animations</a>
                        <a class="collapse-item" href="utilities-other.html">Other</a>
                    </div>
                </div>
            </li> -->

            <!-- Divider -->
            <!-- <hr class="sidebar-divider"> -->

            <!-- Heading -->
            <!-- <div class="sidebar-heading">
                Addons
            </div> -->
            <?php if($user_role === 'admin' ): ?>
            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapsePost"
                    aria-expanded="true" aria-controls="collapsePost">
                    <i class="fas fa-fw fa-newspaper"></i>
                    <span>Posts</span>
                </a>
                <div id="collapsePost" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <h6 class="collapse-header">Posts:</h6>
                        <a class="collapse-item" href="<?php echo e(URL::to('add-post')); ?>">Add Post</a>
                        <a class="collapse-item" href="<?php echo e(URL::to('view-post')); ?>">View Post</a>
                    </div>
                </div>
            </li>
            <!-- Nav Item - Pages Collapse Menu -->
            <li class="nav-item">
                <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapsePages"
                    aria-expanded="true" aria-controls="collapsePages">
                    <i class="fas fa-fw fa-file"></i>
                    <span>Pages</span>
                </a>
                <!-- <div id="collapsePages" class="collapse" aria-labelledby="headingPages" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <h6 class="collapse-header">Login Screens:</h6>
                        <a class="collapse-item" href="login.html">Login</a>
                        <a class="collapse-item" href="register.html">Register</a>
                        <a class="collapse-item" href="forgot-password.html">Forgot Password</a>
                        <div class="collapse-divider"></div>
                        <h6 class="collapse-header">Other Pages:</h6>
                        <a class="collapse-item" href="404.html">404 Page</a>
                        <a class="collapse-item" href="blank.html">Blank Page</a>
                    </div>
                </div> -->
                <div id="collapsePages" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <h6 class="collapse-header">Posts:</h6>
                        <a class="collapse-item" href="<?php echo e(URL::to('add-page')); ?>">Add Page</a>
                        <a class="collapse-item" href="<?php echo e(URL::to('view-page')); ?>">View Pages</a>
                    </div>
                </div>

            </li>
            <?php endif; ?>
            <!-- Nav Item - Charts -->
            <!-- <li class="nav-item">
                <a class="nav-link" href="charts.html">
                    <i class="fas fa-fw fa-chart-area"></i>
                    <span>Charts</span></a>
            </li> -->

            <!-- Nav Item - Tables -->
            <!-- <li class="nav-item">
                <a class="nav-link" href="tables.html">
                    <i class="fas fa-fw fa-table"></i>
                    <span>Tables</span></a>
            </li> -->

            <!-- Divider -->
            <!-- <hr class="sidebar-divider d-none d-md-block"> -->

            <!-- Sidebar Toggler (Sidebar) -->
            <div class="text-center d-none d-md-inline">
                <button class="rounded-circle border-0" id="sidebarToggle"></button>
            </div>

            <!-- Sidebar Message -->
            

        </ul><?php /**PATH /Users/chaitalidigar/Desktop/laravel-tutorials/my-laravel-app/resources/views/partials/sidebar.blade.php ENDPATH**/ ?>
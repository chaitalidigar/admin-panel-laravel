<?php echo $__env->make('includes.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<!DOCTYPE html>
<html>
<head>
    <title>Laravel Home</title>
</head>
<body>
    <?php echo e(URL::current()); ?>

    <h1>This is home page <?php echo e($name); ?></h1>
    <a href="https://www.google.com" target="_blank">Go to Google</a>
    <a href="/user-form" target="_blank">Go to user form </a>
    <a href="/username/abhijit" target="_blank">Go to about me</a>
    <a href="<?php echo e(URL::to('user-form')); ?>" target="_blank">Go to user form</a>
    <a href="<?php echo e(URL::to('username',['laravel'])); ?>" target="_blank">Go to user form</a>
    <a href="<?php echo e(route('hom')); ?>" target="_blank">Go to user form</a>
    <p><?php echo "Running";?></p>
    <p> here is the userlist1 <?php echo e($users[0]); ?><p>
    <p> here is the userlist2 <?php echo e($users[1]); ?><p>
    <p> here is the userlist3 <?php echo e($users[2]); ?><p>
        <?php if($name== 'anil'): ?>
        <h2>this the fisrt name anil</h2>
        <?php elseif($name=='plash'): ?>
        <h2>ythis name of palash</h2>
        <?php else: ?>
        <h2>other person</h2>
        <?php endif; ?>


        <div>
            <?php for($i=0;$i<=10;$i++): ?>
            <h3><?php echo e($i); ?></h3>
            <?php endfor; ?>
        </div>
        <div>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $username): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <h3><?php echo e($username); ?></h3>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <?php echo $__env->make('includes.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        
</body>
</html>
<?php /**PATH /Users/chaitalidigar/Desktop/laravel-tutorials/my-laravel-app/resources/views/index.blade.php ENDPATH**/ ?>
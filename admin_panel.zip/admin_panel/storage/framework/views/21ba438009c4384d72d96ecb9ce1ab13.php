<div>
    <!-- Knowing is not enough; we must apply. Being willing is not enough; we must do. - Leonardo da Vinci -->
     <h1>Case studies about <?php echo e($name); ?></h1>
</div>
<?php /**PATH /Users/chaitalidigar/Desktop/laravel-tutorials/my-laravel-app/resources/views/casestudies.blade.php ENDPATH**/ ?>
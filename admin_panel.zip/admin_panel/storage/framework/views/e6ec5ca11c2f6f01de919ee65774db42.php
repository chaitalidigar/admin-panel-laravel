<!DOCTYPE html>
<html>
<head>
  <title>Employee list</title>
  <style>
    table {
      width: 50%;
      border-collapse: collapse;
    }
    th, td {
      border: 1px solid #333;
      padding: 8px;
      text-align: left;
    }
    th {
      background-color: #f2f2f2;
    }
  </style>
</head>
<body>

  <h2>Employee list</h2>
  <!-- <h3><?php echo e(print_r($sqluser)); ?></h3> -->

  <table>
    <thead>
      <tr>
        <th>#</th>
        <th>Name</th>
        <th>Email</th>
        <th>Created date</th>
      </tr>
    </thead>
    <tbody>
    <?php $i = 1; ?>
        <?php $__currentLoopData = $sqluser; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $userdata): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
       

      <tr>
        <td><?php echo e($i); ?></td>
        <td><?php echo e($userdata->name); ?></td>
        <td><?php echo e($userdata->email); ?></td>
        <td><?php echo e($userdata->created_at); ?></td>
      </tr>
      <?php $i++; ?>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
    
    </tbody>
  </table>

</body>
</html>

<?php /**PATH /Users/chaitalidigar/Desktop/laravel-tutorials/my-laravel-app/resources/views/employee.blade.php ENDPATH**/ ?>
<li class="nav-item">
    <a class="nav-link" data-widget="fullscreen" href="#" role="button">
        <i class="fas fa-expand-arrows-alt"></i>
    </a>
</li>
<?php /**PATH /Users/chaitalidigar/Desktop/laravel-tutorials/my-laravel-app/vendor/jeroennoten/laravel-adminlte/src/../resources/views/partials/navbar/menu-item-fullscreen-widget.blade.php ENDPATH**/ ?>
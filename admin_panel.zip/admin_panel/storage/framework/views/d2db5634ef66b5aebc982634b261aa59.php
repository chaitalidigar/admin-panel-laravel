<form action ="urlaction" method="post">
        <?php echo csrf_field(); ?>
        <p><?php echo e(URL::previous()); ?></p>
        <label for="name">Full Name</label>
        <input type="text" id="name" name="name" placeholder="Your full name" value="<?php echo e(old('name')); ?>" >
        
        <label for="email">Email</label>
        <input type="text" id="email" name="email" placeholder="example@mail.com" value="<?php echo e(old('email')); ?>" >
        <button type="submit">submit</button>
</form>
<?php /**PATH /Users/chaitalidigar/Desktop/laravel-tutorials/my-laravel-app/resources/views/user-practice.blade.php ENDPATH**/ ?>
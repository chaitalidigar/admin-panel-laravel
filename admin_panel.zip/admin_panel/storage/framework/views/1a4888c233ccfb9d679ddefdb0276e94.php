
<?php if (isset($component)) { $__componentOriginal94cafefcfbb8f570ea4db79bd99d735b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal94cafefcfbb8f570ea4db79bd99d735b = $attributes; } ?>
<?php $component = App\View\Components\MessageBanner::resolve(['msg' => 'login sucessfully done!!!'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('message-banner'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\MessageBanner::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal94cafefcfbb8f570ea4db79bd99d735b)): ?>
<?php $attributes = $__attributesOriginal94cafefcfbb8f570ea4db79bd99d735b; ?>
<?php unset($__attributesOriginal94cafefcfbb8f570ea4db79bd99d735b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal94cafefcfbb8f570ea4db79bd99d735b)): ?>
<?php $component = $__componentOriginal94cafefcfbb8f570ea4db79bd99d735b; ?>
<?php unset($__componentOriginal94cafefcfbb8f570ea4db79bd99d735b); ?>
<?php endif; ?>
    <h1>About me: i am a php developer, and stsrt learning <?php echo e($name); ?></h1>
<h2><?php echo e(URL::current()); ?></h2>

<h3><?php echo e(URL::previous()); ?></h3>
    <style>
        .sucess{
    background: green;
    color: black;
    padding: 3px 10px;
    margin: 19px;
    border-radius: 3px;
        }
        </style>
<?php /**PATH /Users/chaitalidigar/Desktop/laravel-tutorials/my-laravel-app/resources/views/aboutme.blade.php ENDPATH**/ ?>
<div>
    <!-- It is not the man who has too little, but the man who craves more, that is poor. - Seneca -->
     <h1>Our details page</h1>
     <h2><?php echo e(URL::current()); ?></h2>
</div>
<?php /**PATH /Users/chaitalidigar/Desktop/laravel-tutorials/my-laravel-app/resources/views/ourdetails.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title', 'Admin Dashboard'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Admin Panel</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <p>Welcome, Admin!</p>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/chaitalidigar/Desktop/laravel-tutorials/my-laravel-app/resources/views/admin/dashboardd.blade.php ENDPATH**/ ?>
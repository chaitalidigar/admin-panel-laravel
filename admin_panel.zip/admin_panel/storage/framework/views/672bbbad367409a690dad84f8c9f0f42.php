<div>
    <!-- I have not failed. I've just found 10,000 ways that won't work. - Thomas Edison -->
     <h1>About us</h1>
</div>
<?php /**PATH /Users/chaitalidigar/Desktop/laravel-tutorials/my-laravel-app/resources/views/aboutus.blade.php ENDPATH**/ ?>
<!DOCTYPE html>
<html>
<head>
  <title>Student list</title>
  <style>
    table {
      width: 50%;
      border-collapse: collapse;
    }
    th, td {
      border: 1px solid #333;
      padding: 8px;
      text-align: left;
    }
    th {
      background-color: #f2f2f2;
    }
  </style>
</head>
<body>

  <h2>Student list</h2>
 
  <h3>table 1<h3>
  <table>
    <thead>
      <tr>
        <th>#</th>
        <th>Name</th>
        <th>Username</th>
        <th>Email</th>
      </tr>
    </thead>
    <tbody>
    <?php $i = 1; ?>
        <?php $__currentLoopData = $student_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student_data_list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

      <tr>
        <td><?php echo e($i); ?></td>
        <td><?php echo e($student_data_list->name); ?></td>
        <td><?php echo e($student_data_list->email); ?></td>
        <td><?php echo e($student_data_list->created_at); ?></td>
      </tr>
      <?php $i++; ?>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
    
    </tbody>
  </table>
</body>
</html>

<?php /**PATH /Users/chaitalidigar/Desktop/laravel-tutorials/my-laravel-app/resources/views/home.blade.php ENDPATH**/ ?>
<div>
    <!-- Very little is needed to make a happy life. - Marcus Aurelius -->
     <h1 class="sucess"><?php echo e($msg); ?></h1>
</div><?php /**PATH /Users/chaitalidigar/Desktop/laravel-tutorials/my-laravel-app/resources/views/components/message-banner.blade.php ENDPATH**/ ?>
<!DOCTYPE html>
<html>
<head>
    <title>User Form</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
            padding: 40px;
        }
        .form-container {
            background-color: white;
            padding: 30px;
            max-width: 500px;
            margin: auto;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .form-container h2 {
            text-align: center;
            margin-bottom: 25px;
        }
        label {
            display: block;
            margin-top: 15px;
            font-weight: bold;
        }
        input[type="text"],
        input[type="email"],
        input[type="password"],
        textarea {
            width: 100%;
            padding: 10px;
            margin-top: 8px;
            border: 1px solid #ccc;
            border-radius: 6px;
        }
        button {
            margin-top: 20px;
            width: 100%;
            padding: 10px;
            background-color: #4CAF50;
            color: white;
            font-size: 16px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
        }
        button:hover {
            background-color: #45a049;
        }
        .input_error{
            border:1px solid red!important;
            color:red;
        }
    </style>
</head>
<body>
<!-- <?php echo e(print_r($errors)); ?> -->
<!-- <?php if($errors->any()): ?>
<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div><?php echo e($error); ?></div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?> -->
<div class="form-container">
    <h2>User Registration Form</h2>
    <form action ="add-user" method="post">
        <?php echo csrf_field(); ?>
        <p><?php echo e(URL::previous()); ?></p>
        <label for="name">Full Name</label>
        <input type="text" id="name" name="name" placeholder="Your full name" value="<?php echo e(old('name')); ?>" class="<?php echo e($errors->first('name')?'input_error':''); ?>">
        <span><?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
        <label for="email">Email</label>
        <input type="text" id="email" name="email" placeholder="example@mail.com" value="<?php echo e(old('email')); ?>" class="<?php echo e($errors->first('email')?'input_error':''); ?>">
        <span><?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
        <label for="password">Password</label>
        <input type="password" id="password" name="password" placeholder="********" class="<?php echo e($errors->first('password')?'input_error':''); ?>">
        <span><?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span>
        <h4>User skill</h4>
        <div style="display:flex";>
        
        <input type="checkbox" id="php" name="skill[]" value="PHP" >
        <label for="php">Php</label>
        <input type="checkbox" id="react" name="skill[]" value="React">
        <label for="react">React</label>
        <input type="checkbox" id="node" name="skill[]" value="node">
        <label for="node">Node js</label>
        <input type="checkbox" id="mongodb" name="skill[]" value="mongodb">
        <label for="mongodb">MongoDB</label>
        
    </div>

        <label for="about">About You</label>
        <textarea id="about" name="about" placeholder="Tell us about yourself" rows="4"></textarea>

        <button type="submit">Register</button>
    </form>
</div>

</body>
</html>
<?php /**PATH /Users/chaitalidigar/Desktop/laravel-tutorials/my-laravel-app/resources/views/user-form.blade.php ENDPATH**/ ?>
<!DOCTYPE html>
<html>
<head>
    <title>User Form</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
            padding: 40px;
        }
        .form-container {
            background-color: white;
            padding: 30px;
            max-width: 500px;
            margin: auto;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .form-container h2 {
            text-align: center;
            margin-bottom: 25px;
        }
        label {
            display: block;
            margin-top: 15px;
            font-weight: bold;
        }
        input[type="text"],
        input[type="email"],
        input[type="password"],
        textarea {
            width: 100%;
            padding: 10px;
            margin-top: 8px;
            border: 1px solid #ccc;
            border-radius: 6px;
        }
        button {
            margin-top: 20px;
            width: 100%;
            padding: 10px;
            background-color: #4CAF50;
            color: white;
            font-size: 16px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
        }
        button:hover {
            background-color: #45a049;
        }
        .input_error{
            border:1px solid red!important;
            color:red;
        }
    </style>
</head>
<body>
<!-- {{print_r($errors)}} -->
<!-- @if($errors->any())
@foreach($errors->all() as $error)
<div>{{$error}}</div>
@endforeach
@endif -->
<div class="form-container">
    <h2>User Registration Form</h2>
    <form action ="add-user" method="post">
        @csrf
        <p>{{URL::previous()}}</p>
        <label for="name">Full Name</label>
        <input type="text" id="name" name="name" placeholder="Your full name" value="{{old('name')}}" class="{{$errors->first('name')?'input_error':''}}">
        <span>@error('name'){{$message}}@enderror</span>
        <label for="email">Email</label>
        <input type="text" id="email" name="email" placeholder="example@mail.com" value="{{old('email')}}" class="{{$errors->first('email')?'input_error':''}}">
        <span>@error('email'){{$message}}@enderror</span>
        <label for="password">Password</label>
        <input type="password" id="password" name="password" placeholder="********" class="{{$errors->first('password')?'input_error':''}}">
        <span>@error('password'){{$message}}@enderror</span>
        <h4>User skill</h4>
        <div style="display:flex";>
        
        <input type="checkbox" id="php" name="skill[]" value="PHP" >
        <label for="php">Php</label>
        <input type="checkbox" id="react" name="skill[]" value="React">
        <label for="react">React</label>
        <input type="checkbox" id="node" name="skill[]" value="node">
        <label for="node">Node js</label>
        <input type="checkbox" id="mongodb" name="skill[]" value="mongodb">
        <label for="mongodb">MongoDB</label>
        
    </div>

        <label for="about">About You</label>
        <textarea id="about" name="about" placeholder="Tell us about yourself" rows="4"></textarea>

        <button type="submit">Register</button>
    </form>
</div>

</body>
</html>

<!DOCTYPE html>
<html>
<head>
  <title>Student list</title>
  <style>
    table {
      width: 50%;
      border-collapse: collapse;
    }
    th, td {
      border: 1px solid #333;
      padding: 8px;
      text-align: left;
    }
    th {
      background-color: #f2f2f2;
    }
  </style>
</head>
<body>

  <h2>Student list</h2>
 
  <table>
    <thead>
      <tr>
        <th>#</th>
        <th>Name</th>
        <th>Email</th>
        <th>Created date</th>
      </tr>
    </thead>
    <tbody>
    @php $i = 1; @endphp
        @foreach($student_data as $studentdata)
       

      <tr>
        <td>{{$i}}</td>
        <td>{{$studentdata->name}}</td>
        <td>{{$studentdata->email}}</td>
        <td>{{$studentdata->created_at}}</td>
      </tr>
      @php $i++; @endphp
      @endforeach
        
    
    </tbody>
  </table>
  <div>&nbsp;</div>
  <table>
    <thead>
      <tr>
        <th>#</th>
        <th>Name</th>
        <th>Username</th>
        <th>Email</th>
      </tr>
    </thead>
    <tbody>
    @php $i = 1; @endphp
        @foreach($user_data as $userdata)

      <tr>
        <td>{{$i}}</td>
        <td>{{$userdata['name']}}</td>
        <td>{{$userdata['username']}}</td>
        <td>{{$userdata['email']}}</td>
      </tr>
      @php $i++; @endphp
      @endforeach
        
    
    </tbody>
  </table>

</body>
</html>


@extends('adminlte::page')

@section('title', 'Admin Dashboard')

@section('content_header')
    <h1>Admin Panel</h1>
@endsection

@section('content')
    <p>Welcome, Admin!</p>
@endsection

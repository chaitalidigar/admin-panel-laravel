<form action ="urlaction" method="post">
        @csrf
        <p>{{URL::previous()}}</p>
        <label for="name">Full Name</label>
        <input type="text" id="name" name="name" placeholder="Your full name" value="{{old('name')}}" >
        
        <label for="email">Email</label>
        <input type="text" id="email" name="email" placeholder="example@mail.com" value="{{old('email')}}" >
        <button type="submit">submit</button>
</form>

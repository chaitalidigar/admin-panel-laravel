<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            {{ __('Dashboard') }}
        </h2>
    </x-slot>

    <div class="py-10">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">

            {{-- Summary Cards --}}
            <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-6 mb-6">
                <div class="bg-white shadow rounded-lg p-5 text-center">
                    <h3 class="text-sm text-gray-500">Total Users</h3>
                    <p class="text-2xl font-bold text-indigo-600">42</p>
                </div>
                <div class="bg-white shadow rounded-lg p-5 text-center">
                    <h3 class="text-sm text-gray-500">Total Students</h3>
                    <p class="text-2xl font-bold text-green-600">78</p>
                </div>
                <div class="bg-white shadow rounded-lg p-5 text-center">
                    <h3 class="text-sm text-gray-500">Active Sessions</h3>
                    <p class="text-2xl font-bold text-yellow-600">5</p>
                </div>
                <div class="bg-white shadow rounded-lg p-5 text-center">
                    <h3 class="text-sm text-gray-500">Messages</h3>
                    <p class="text-2xl font-bold text-red-600">13</p>
                </div>
            </div>

            {{-- Chart / Table Placeholder --}}
            <div class="bg-white shadow rounded-lg p-6">
                <h3 class="text-lg font-semibold text-gray-700 mb-4">Recent Activity</h3>
                <p class="text-gray-500">You can display recent user actions or data summaries here.</p>
            </div>

        </div>
    </div>
</x-app-layout>

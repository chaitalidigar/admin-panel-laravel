<div>
    <!-- Very little is needed to make a happy life. - Marcus Aurelius -->
     <h1 class="sucess">{{$msg}}</h1>
</div>
<?php

use App\Http\Controllers\ProfileController;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\StudentController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\CustomerController;
use App\Http\Controllers\TaskController;
use App\Http\Controllers\Leadcontroller;
use App\Http\Controllers\CmsPagesController;



Route::get('/', function () {
    return view('welcome');
});

//authencation
Route::get('/dashboard', function () {
    return view('admin.dashboard');
})->middleware(['auth', 'verified'])->name('dashboard');

Route::middleware('auth')->group(function () {
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
});

Route::get('profile/{id}',[ProfileController::class,'get_profile']);


//user
Route::get('add-user',[UserController::class,'adduserdata']);
Route::post('add_new_user_action',[UserController::class,'addnewuser']);
Route::get('view-user',[UserController::class,'viewuser']);
Route::get('edit-user/{id}',[UserController::class,'edituser']);
Route::post('update-user/{id}', [UserController::class, 'updateuser']);
Route::get('delete-user/{id}', [UserController::class, 'deleteuser']);

//customer
Route::get('add-customer',[CustomerController::class,'addcustomer']);
Route::post('add_new_customer_action',[CustomerController::class,'addcustomeraction']);
Route::get('view-customer',[CustomerController::class,'viewcustomer']);
Route::get('edit-customer/{id}',[CustomerController::class,'editcustomer']);
Route::post('update-customer/{id}', [CustomerController::class,'updatecustomer']);
Route::get('delete-customer/{id}',[CustomerController::class,'deletecustomer']);

//task
Route::get('add-task',[TaskController::class,'addtashk']);
Route::post('add_new_task_action',[TaskController::class,'addtaskaction']);
Route::get('view-task',[TaskController::class,'viewtask']);
Route::get('edit-task/{id}',[TaskController::class,'edittask']);
Route::post('update-task/{id}',[TaskController::class,'updatetask']);
Route::get('delete-task/{id}',[TaskController::class,'deletetask']);


//leads
Route::get('view-lead',[Leadcontroller::class,'viewlead']);

//role&permission
Route::view('roles-permission','admin.rolespermission');

//pages
Route::get('add-page',[CmsPagesController::class,'addpage']);
Route::post('add-cms-page-action',[CmsPagesController::class,'addcmspageaction']);
Route::get('view-page',[CmsPagesController::class,'viewpage'])->name('admin.view-page');;
Route::get('edit-page/{id}',[CmsPagesController::class,'editpage']);
Route::post('update-cms-page/{id}',[CmsPagesController::class,'updatepage']);
Route::get('delete-page/{id}',[CmsPagesController::class,'deletepage']);

//my practice
Route::post('add-user',[UserController::class,'addUser']);
Route::get('student-list',[StudentController::class,'getStudents']);
Route::get('user-form',[UserController::class,'useraddform']);
Route::get('user',[UserController::class,'userfn']);
Route::post('urlaction',[UserController::class,'urlactionfn']);
//
require __DIR__.'/auth.php';

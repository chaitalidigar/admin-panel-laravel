<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;
// use Illuminate\Support\Facades\DB;
use App\Models\Student;

class StudentController extends Controller
{
    //
    function showlist(){
        return ' show all student list';
    }

    function add(){
        return 'add form is working';
    }

    function delete(){
        return 'delete section is working';
    }

    function getName($name){
        return $name;
    }

    function getStudents(){
        $data = new \App\Models\Student;//another function if  you wanted add in that function and view
        echo $data->test_demo();
        $students= \App\Models\Student::all();
        $response = Http::get('https://jsonplaceholder.typicode.com/users');
        $users = $response->json();
       // echo "student function";
       return view('student',['student_data'=>$students,'user_data'=>$users]);
    }

    function queries(){
        //$sql= DB::table('students')->get();// select query
        // $sql= DB::table('students')->insert([// inserted query
        //     'name'=>'Rabi kumar',
        //     'email'=> 'rabikumarself@test.com'
        // ]);
        // if($sql){
        //     return "Data inserted sucessfully";
        // }else{
        //     return "Something worng";
        // }

        // $sql = DB::table('students')->where('name','subhas')->get();// where condition
        // echo $sql;

        // $sql = DB::table('students')->where('id','3')->update([
        //     'email'=>'anil123@test.com'
        // ]);
        // if($sql){
        //     return "Updated sucessfully";

        // }else{
        //     return "Sorry not updated!!";
        // }

        // $sql = DB::table('students')->where('id','2')->delete();
        // if($sql){ 
        //     return "Deleted sucessfully";

        // }else{
        //     return "Sorry not updated!!";
        // }

        $sql= Student::get();
         return view('home',['student_list' =>$sql]);

        //  $sql = Student::where('id','3')->update([
        //     'email'=>'anil1234@test.com'
        // ]);
        // if($sql){
        //     return "Updated sucessfully";

        // }else{
        //     return "Sorry not updated!!";
        // }

        // $sql = Student::where('id','3')->deleted([
        //     'email'=>'anil1234@test.com'
        // ]);
        // if($sql){
        //     return "Updated sucessfully";

        // }else{
        //     return "Sorry not updated!!";
        // }


    }
}

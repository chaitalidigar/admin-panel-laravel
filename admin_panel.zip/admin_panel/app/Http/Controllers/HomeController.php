<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;// db fetch

class HomeController extends Controller
{
    //

    function aboutus(){
        return DB::select('select * from users');
        //return view('aboutus');
    }

    function casestudies($name){
        return view('casestudies',['name'=>$name]);
    }

    function employee(){
        $sqluser= DB::select('select * from users');
        return view('employee',['sqluser' => $sqluser]);
    }
}

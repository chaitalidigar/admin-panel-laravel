<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Cmspage;

class CmsPagesController extends Controller
{
    //
    function viewpage(){

        $sql= Cmspage::get();

        return view('admin.view-page',['sql'=>$sql]);
    }

    function addpage(){
        return view('admin.add-page');
    }

    function addcmspageaction(Request $request){

        // Validate incoming request
    $request->validate([
        'title'            => 'required|string|max:255',
        'slug'             => 'required|string|max:255|unique:cmspages,slug',
        'content'          => 'required',
        'meta_title'       => 'nullable|string|max:255',
        'meta_description' => 'nullable|string',
        'meta_keywords'    => 'nullable|string|max:255',
        'status'           => 'required|boolean',
    ]);

    // Insert into database
    Cmspage::create($request->all());
    // Redirect with success message
   return redirect()->back()->with('success', 'CMS Page added successfully!');
   //return redirect()->route('view-page')->with('success', 'CMS Page added successfully!');


    }

    function editpage($id){

        $pages = Cmspage::where('id', $id)->firstOrFail();//Customer::findOrFail($id); // Get customer by ID or fail
        return view('admin.edit-page', ['pages' => $pages]);

    }

    function updatepage(Request $request, $id){

        // Validate incoming request
    $request->validate([
        'title'            => 'required|string|max:255',
        'slug'             => 'required|string|max:255|unique:cmspages,slug,' . $id,
        'content'          => 'required',
        'meta_title'       => 'nullable|string|max:255',
        'meta_description' => 'nullable|string',
        'meta_keywords'    => 'nullable|string|max:255',
        'status'           => 'required|boolean',
    ]);

    // Find and update the record
    $page = Cmspage::findOrFail($id);
    $page->title            = $request->title;
    $page->slug             = $request->slug;
    $page->content          = $request->content;
    $page->meta_title       = $request->meta_title;
    $page->meta_description = $request->meta_description;
    $page->meta_keywords    = $request->meta_keywords;
    $page->status           = $request->status;
    $page->save();

    // Redirect back with success message
    //return redirect()->back()->with('success', 'CMS Page updated successfully!');
     return redirect()->route('admin.view-page')->with('success', 'CMS Page updated successfully!');

    }

    public function deletepage($id)
{
    $page = Cmspage::findOrFail($id);
    $page->delete();

    return redirect()->back()->with('success', 'CMS Page deleted successfully!');
}
}

<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Customer;
use Illuminate\Support\Facades\DB;

class CustomerController extends Controller
{
    //

    function addcustomer(){
        $states = DB::table('states')->orderBy('name')->get();
        return view('admin.add-customer',['states'=>$states]);
    }

    function addcustomeraction(Request $request){

        //return $request;
        // Validate incoming request
        $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|email|unique:customers,email',
            'phone' => 'required',
            'address' => 'required',
            'state' => 'required',
            'country' => 'required',
        ]);

        // Insert into database
        Customer::create($request->all());
         // Redirect with success message
        return redirect()->back()->with('success', 'Customer added successfully!');

    }

    function viewcustomer(){
        $sql= Customer::get();

        return view('admin.view-customer',['sql'=>$sql]);
    }

    function editcustomer($id){

        $customer = Customer::where('id', $id)->firstOrFail();//Customer::findOrFail($id); // Get customer by ID or fail
        $states = DB::table('states')->orderBy('name')->get();
        return view('admin.edit-customer', ['customer' => $customer,'states'=> $states]);

    }

    function updatecustomer(Request $request, $id){
        $customer = Customer::findOrFail($id);

        $customer->update([
            'name'    => $request->name,
            'email'   => $request->email,
            'phone'   => $request->phone,
            'address' => $request->address,
            'state'   => $request->state,
            'country' => $request->country,
        ]);

        return redirect()->back()->with('success', 'Customer data updated successfully!');
    }

    function deletecustomer($id){
        $customer = Customer::where('id', $id)->firstOrFail();//Customer::findOrFail($id); // Get customer by ID or fail
        // Delete the customer
        $customer->delete();

        // Redirect back with success message
        return redirect()->back()->with('success', 'Customer deleted successfully!');

    }
}

<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Task;

class TaskController extends Controller
{
    //
    function addtashk(){
        return view('admin.add-task');
    }
    function addtaskaction(Request $request){

        $request->validate([
            'task_name'=>'required',
        ]);

        //insert into table
        Task::create(['task_name'=>$request->input('task_name')]);
         // Redirect with success message
         return redirect()->back()->with('success','Task added sucessfully ');

    }
    function viewtask(){
        $get_task= Task::get();
        return view('admin.view-task',['get_task'=>$get_task]);

    }
    function edittask($id){
        $task_by_id = Task::where('id',$id)->firstOrfail();
        return view('admin.edit-task',['get_id' => $task_by_id]);

    }
    function updatetask(Request $request, $id){
        $task_data = Task::findOrFail($id);
        $task_data->update([
            'task_name' => $request->task_name,
        ]);
         return redirect()->back()->with('success','Task data updated sucessfully');
        
    }
    function deletetask($id){
        $get_task_id = Task::where('id',$id)->firstOrfail();
        $get_task_id->delete();

        // Redirect back with success message
        return redirect()->back()->with('success', 'Customer deleted successfully!');

    }
}

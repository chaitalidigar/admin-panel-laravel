<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
//use Illuminate\Support\Facades\DB;
use App\Models\User;

class UserController extends Controller
{
    //learning
    function getName(){
        echo "c my name is chaitali digar";
    }
    function getUserName($name){
        //return " hello this is my project :".$name;

        return view('aboutme',['name'=>$name]); // for index page
    }

    function getAllUser(){
        $name= 'Anil';
        $users = ['CHAITALI','DILIP','MALATI'];
        return view('index',['name'=>$name],['users'=>$users]); // for aboutme page
    }

    function useraddform(){
        return view('user-form');
    }

    function addUser(Request $request){

        //input validation
        $request->validate(
            ['name'=>'required|min:3|max:10',
            'email'=>'required|email',
            'password' => 'required|string|max:10',
            'skill'=>'required'],
            ['name.required'=> 'Please fill the blanks',
            'name.min' => 'Sorry atleast minnimun 3 charecters needed!!',
            'name.max' => 'Sorry is its more then ten digit, cant accepted!!',
            'email.required'=> 'Please fill the blanks',
            'email.email'=> 'Worng format!',
            'password.required'=> 'Please fill the blanks',
            'password.max'=> 'Please out max 10 digits!']
        );
       
       return $request; // for user-form page
    //    echo $request->name;
    //    echo "<br>";
    //    echo $request->email;
    //    echo "<br>";
    //    echo $request->password;
    //    echo "<br>";
    //    print_r($request->skill);
    //    echo $request->skill[0];
    //    echo "<br>";
    //    echo $request->skill[1];
    //    echo "<br>";
    //    echo $request->skill[2];
    //    echo "<br>";
       //echo $request->about;
    }

    function display(){// nemaed routes(handle)
       // return view('home');// for home.blade.php
       //return redirect()->to('user-form');
       return to_route('hom');
    }

    function showfunction(){
        echo "is show function start";
    }
    function savefunction(){
        echo "is save function start";
    }
    function userfn(){
        return view('user-practice');
    }

    function urlactionfn(Request $request){

        echo "Method ". $request->method();
        echo "<br>";
        echo "path ". $request->path();
        echo "<br>";
        echo "url ". $request->url();

        if($request->isMethod('post')){
            echo "methos is post";
        }else{
            echo " not ";
        }

    }
    ///learning

    function adduserdata(){
        return view('admin.add-user');
    }

    function addnewuser(Request $request){
        //return $request;

        //insert to database

        $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|email|unique:users,email',
            'password' => 'required',
            
        ]);

        // Insert into database
        User::create($request->all());
         // Redirect with success message
        return redirect()->back()->with('success', 'User added successfully!');
        
    }

    function viewuser(){
        $sql= User::get();

        return view('admin.view-user',['sql'=>$sql]);
    }

    function edituser($id){
        $user = User::where('id', $id)->firstOrFail();//Customer::findOrFail($id); // Get customer by ID or fail
        return view('admin.edit-user', ['user' => $user]);
    }

    function updateuser(Request $request, $id){
        //return $request;
        $user = User::findOrFail($id);

        $user->update([
            'name'    => $request->name,
            'email'   => $request->email,
            'password'   => $request->password,
        
        ]);

        return redirect()->back()->with('success', 'User data updated successfully!');
    }


    function deleteuser($id){
        $user =User::where('id', $id)->firstOrFail();//Customer::findOrFail($id); // Get customer by ID or fail
        // Delete the customer
        $user->delete();

        // Redirect back with success message
        return redirect()->back()->with('success', 'User deleted successfully!');

    }
}

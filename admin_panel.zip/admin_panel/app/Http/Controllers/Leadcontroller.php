<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class Leadcontroller extends Controller
{
    //
    function viewlead(){
        return view('admin.view-lead');
    }
}

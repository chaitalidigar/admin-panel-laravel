<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Student extends Model
{
    //
    //protected $table = 'tbl_students';//if you are using another table;

    public $timestamps = false;
    function test_demo(){
         echo 'test';
    }
}

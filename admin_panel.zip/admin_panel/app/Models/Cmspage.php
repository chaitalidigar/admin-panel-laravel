<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Cmspage extends Model
{
    //

    //protected $table = 'cmspages';
    public $timestamps = true;

    protected $fillable = [
        'title',
        'slug',
        'content',
        'meta_title',
        'meta_description',
        'meta_keywords',
        'status',
    ];

}
